Copy the jar files in this directory to repository/components/lib of the ESB distribution.
