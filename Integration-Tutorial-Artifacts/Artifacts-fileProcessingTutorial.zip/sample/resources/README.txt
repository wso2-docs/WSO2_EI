Copy the smooks-config.xml file in to resources/ directory.
