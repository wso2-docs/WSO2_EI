UPDATE ACT_HI_COMMENT
SET USER_ID_ = `pseudonym`
WHERE USER_ID_ = `username`
