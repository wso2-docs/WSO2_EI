UPDATE ACT_HI_VARINST
SET TEXT_ = `pseudonym`
WHERE TEXT_ = `username`
