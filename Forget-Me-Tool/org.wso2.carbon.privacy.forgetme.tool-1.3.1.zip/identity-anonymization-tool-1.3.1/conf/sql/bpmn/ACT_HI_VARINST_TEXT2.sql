UPDATE ACT_HI_VARINST
SET TEXT2_ = `pseudonym`
WHERE TEXT2_ = `username`
