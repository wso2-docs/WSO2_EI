UPDATE ACT_HI_TASKINST
SET OWNER_ = `pseudonym`
WHERE OWNER_ = `username`
