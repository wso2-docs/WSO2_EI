Add related datasources.xml files to this directory or point to the correct datasources directory by modifying
config.json file.